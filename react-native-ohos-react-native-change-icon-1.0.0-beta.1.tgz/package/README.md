# @oh-rn/react-native-change-icon for HarmonyOS

本项目基于 [react-native-change-icon](https://github.com/skb1129/react-native-change-icon) 开发，为 React Native 鸿蒙（OpenHarmony）适配版本。

## 版本对应关系

| 鸿蒙适配包版本 | 原始库版本 | 支持 RN 版本 | Autolink | 编译 API 版本 |
| ------------ | ---------- | ------------ | -------- | ------------- |
| 1.0.0-beta.1 | 5.0.0 | 0.72+ | 是 | API12+（动态图标接口需设备 5.0.3(15)+） |

## 安装

```bash
npm install @oh-rn/react-native-change-icon
```

## 使用

```tsx
import { changeIcon, getIcon, resetIcon } from 'react-native-change-icon';

// 切换到 AGC 配置的动态图标（iconId 为字符串 ID）
changeIcon('icon_id_dark')
  .then(name => console.log('当前图标:', name)) // resolve: 生效图标名
  .catch(e => console.warn(e.message));          // reject: 如 HARMONY:ICON_INVALID:xxx

// 查询当前启用的图标（默认图标时 resolve "Default"）
getIcon().then(name => console.log(name));

// 恢复默认图标（= changeIcon() 空参调用）
resetIcon()
  .then(name => console.log(name)) // resolve: "Default"
  .catch(e => console.warn(e.message)); // 已是默认时 reject HARMONY:AGC_1006800012
```

> 所有方法均为 Promise：成功 resolve 生效图标名（字符串），失败 reject 携带错误码字符串。

> import 时使用原库名 `'react-native-change-icon'`，而非鸿蒙包名 `@oh-rn/react-native-change-icon`（由 RNOH `harmony.alias` 自动映射）。

**平台差异**：
- HarmonyOS 上「应用内动态切换桌面图标」的唯一官方途径是 AppGallery Kit 图标管理服务（`appInfoManager`，云端模式）：**`changeIcon` 的参数是 AGC 云端配置的动态图标 ID（iconId）**，不是 Android/iOS 那样本地打包的图标资源名（鸿蒙无 activity-alias / CFBundleAlternateIcons 本地图标机制）。
- 切换成功后由系统直接刷新桌面图标，**无需重启应用**（原 Android 端会 finish Activity 触发重启，鸿蒙无此交互）。
- `resetIcon()` / 空参 `changeIcon()` 在已是默认图标时 reject `HARMONY:AGC_1006800012`（对齐原 Android 端 `ICON_ALREADY_USED` 短路拒绝语义）。
- 设备不支持该系统能力时（系统低于 5.0.3(15)）reject `HARMONY:NOT_SUPPORTED`。

**权限要求**：
- 无需任何 `ohos.permission` 声明，也无需运行时动态申请。

## Link

| 版本 | 是否支持 Autolink |
|------|------------------|
| 当前版本 | 是 |

如使用版本支持 Autolink 且工程已接入，可跳过手动配置。

<details>
<summary>Manual Link 配置</summary>

> **说明**：本模块需要同时在 C++ 侧和 ETS 侧注册 Package。

### 1. Overrides RN SDK

在工程根目录 `oh-package.json5` 添加：

```json
{
  "overrides": {
    "@rnoh/react-native-openharmony": "./react_native_openharmony"
  }
}
```

### 2. 引入原生端依赖

打开 `entry/oh-package.json5`，添加：

```json
"dependencies": {
  "@oh-rn/react-native-change-icon": "file:../../node_modules/@oh-rn/react-native-change-icon/harmony/change_icon.har"
}
```

执行 `ohpm install`。

### 3. 配置 CMakeLists

打开 `entry/src/main/cpp/CMakeLists.txt`，添加：

```cmake
set(OH_MODULES "${CMAKE_CURRENT_SOURCE_DIR}/../../../oh_modules")

add_subdirectory("${OH_MODULES}/@oh-rn/react-native-change-icon/src/main/cpp" ./change_icon)

target_link_libraries(rnoh_app PUBLIC change_icon)
```

### 4. 注册 Package（C++ 侧）

打开 `entry/src/main/cpp/PackageProvider.cpp`，添加：

```cpp
#include "ChangeIconPackage.h"

std::vector<std::shared_ptr<Package>> PackageProvider::getPackages(Package::Context ctx) {
    return {
        std::make_shared<ChangeIconPackage>(ctx),
    };
}
```

### 5. 注册 Package（ETS 侧）

打开 `entry/src/main/ets/RNPackagesFactory.ets`，添加：

```typescript
import { ChangeIconPackage } from '@oh-rn/react-native-change-icon/ts';

export function createRNPackages(ctx: RNPackageContext): RNPackage[] {
  return [
    new ChangeIconPackage(ctx),
  ];
}
```

</details>

## 属性 / API

| API | 描述 | 参数 | 返回值 | HarmonyOS 支持 |
|-----|------|------|--------|----------------|
| changeIcon(iconName?) | 切换应用图标；空参/`"Default"` 恢复默认 | iconName?: string（AGC 动态图标 iconId） | Promise\<string\>（生效图标名） | ⚠️ 需特定条件 |
| resetIcon() | 恢复默认图标（= changeIcon() 空参） | 无 | Promise\<string\>（`"Default"`） | ⚠️ 需特定条件 |
| getIcon() | 查询当前启用的图标 | 无 | Promise\<string\>（iconId 或 `"Default"`） | ✅ 完全支持 |

> Spec 层另声明 `getConstants()`，返回空对象（与原库一致，无导出常量）。

### 平台差异
- 参数语义：`changeIcon(iconName)` 的 `iconName` 在 Android/iOS 是本地打包图标名，在 HarmonyOS 是 **AGC 云端配置的动态图标 ID**；鸿蒙不存在本地多图标打包模式，本库按 AGC 图标管理服务实现（`queryDynamicIcons` / `selectDynamicIcon` / `disableDynamicIcon`）。
- `getIcon()` 在未开通服务 / 无动态图标数据（错误码 1006800010）时 resolve `"Default"`，与「当前为默认图标」的事实语义一致。
- 已是当前图标时 `changeIcon` reject `HARMONY:ICON_ALREADY_USED:<id>`，AGC 未配置该 ID 时 reject `HARMONY:ICON_INVALID:<id>`（对齐原库 `ANDROID/IOS:ICON_ALREADY_USED`、`ANDROID:ICON_INVALID`）。
- AGC 错误统一以 `HARMONY:AGC_<code>:<message>` 透传 reject。

### 未实现功能
| API / 能力 | 原因 |
|-----|------|
| 本地打包多图标模式（Android activity-alias / iOS CFBundleAlternateIcons） | 鸿蒙平台无此机制，官方唯一途径为 AGC 云端动态图标，已按其完整实现，非省略 |

### 使用限制
- 需真机且系统 **5.0.3(15)+**，不支持模拟器（Wearable 5.1.1(18)+、TV 5.1.1(19)+）。
- 应用须**正式上架**，并按官方流程邮件申请开通图标管理服务（详见 AppGallery Connect「图标管理服务」文档）；动态图标须在 AGC「分发 > 服务 > 图标管理」创建并过审后客户端才可切换。
- 未满足上述条件时调用走真实错误路径（如 `HARMONY:AGC_1006800010` 无动态图标信息），本库不提供模拟数据。
- 接口依赖 `SystemCapability.AppGalleryService.AppInfoManager`，方法入口已做 `canIUse` 守卫，不支持时 reject `HARMONY:NOT_SUPPORTED`。

## 快速验证（运行 Example）

### 前置条件

| 依赖 | 版本要求 |
|------|----------|
| Node.js | >= 18 |
| DevEco Studio | 5.0+ / 6.0+ |
| HarmonyOS SDK | API 12+ |

### 运行步骤

**1. 克隆仓库**

```bash
git clone <仓库地址>
cd <仓库目录>
```

**2. 安装依赖并构建**

```bash
npm install --legacy-peer-deps
npm pack           # 生成 tgz 包（会自动触发 prepare 构建 JS 产物）
```

**3. 进入 example 目录，安装依赖**

```bash
cd example
npm install --legacy-peer-deps
```

**4. 生成 JS Bundle**

```bash
npm run dev
```

产物：`harmony/entry/src/main/resources/rawfile/bundle.harmony.js`

**5. 用 DevEco Studio 打开鸿蒙工程**

- 打开 DevEco Studio
- 选择 `example/harmony` 目录
- 等待 Sync 完成

**6. 编译并运行 HAP**

在 DevEco Studio 中点击运行按钮，将 HAP 安装到设备/模拟器。

> **注意**：Example 中已预置插件依赖和 Package 注册，无需手动配置 Link。

## 约束与限制

### 兼容性

- RNOH: 0.72+
- HarmonyOS SDK: API 12+
- DevEco Studio: 5.0+

## 遗留问题

无功能性遗留。注意：HarmonyOS 动态图标为 AGC 云端模式，开发/调试期（应用未上架或模拟器）无法走通切换成功路径，属平台服务前提而非适配缺失（见上方「使用限制」）。

## 开源协议

本项目基于 [react-native-change-icon](https://github.com/skb1129/react-native-change-icon)（MIT License）开发，详见 [LICENSE](./LICENSE) 文件。